export interface IUser{
    
    name:string
    password:string
}