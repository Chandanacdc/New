import { Component } from "@angular/core";

@Component({
    selector: 'login-root',
    templateUrl:'./logout.component.html',
   // styleUrls:['./login.component.css']
  
})
export class LogoutComponent{
    title='Logout';
}